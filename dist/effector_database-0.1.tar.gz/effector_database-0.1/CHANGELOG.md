### Version: 0.1.0
    - Created a database for effectors and its sequence
    - Created a page to submit new effector sequences to the database
    - Make the database viewable with an option to filter for specific elements in the database
    - Add the option to view and edit an effector sequence in the database

### Upcomming versions
    - Add FASTA file support
    - Show search filters the user has activated
    - Limit the table size shown
    - Ask confirmation for deleting an effector gene
    - Enable the user to edit the effector ID (or don't show to option to edit it)
    - Manually add the form to html, instead of letting Django do it.
