# Effector database
#### Version 0.1.0
Effector database is a Django app that contains information about effectors.
Visitors can view, search and edit effectors in the database.
There is also the option to add new effectors to the database.

## Quick start

1. Add "effector_database" to your INSTALLED_APPS setting like this:

	```
    INSTALLED_APPS = [
        ...
        'effector_database',
    ]
	```

2. Include the effector_database URLconf in your project urls.py like this:

	```
    path('effector_database/', include('effector_database.urls')),
	```

3. Run `python manage.py migrate` to create the effector_database models.

4. Visit http://127.0.0.1:8000/effector_database/ to view the database.

5. Additional changes can be made to the database as admin via
   http://127.0.0.1:8000/admin/ (you'll need the Admin app enabled)
